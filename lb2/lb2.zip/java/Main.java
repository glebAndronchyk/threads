import java.time.Duration;
import java.time.Instant;

import lb2.java.ComputableArray;

class Main {
    public static void main (String[] args) {
        var ca = new ComputableArray(89999999, 10000);
       
        System.out.println("\n-----\n");

        Instant startAsync = Instant.now();
        var minAsync = ca.minAsync();
        Instant endAsync = Instant.now();
        Duration timeElapsedAsync = Duration.between(startAsync, endAsync);

        System.out.println("Async result:" + minAsync + "\n" + timeElapsedAsync.toMillis() + "ms");
        System.out.println("\n-----\n");

        Instant startSync = Instant.now();
        var minSync = ca.minSync();
        Instant endSync = Instant.now();
        Duration timeElapsedSync = Duration.between(startSync, endSync);

        System.out.println("Sync result:" + minSync + "\n" + timeElapsedSync.toMillis() + "ms");
        
        System.out.println("\n-----\n");
    }
}