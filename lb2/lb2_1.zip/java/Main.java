import java.time.Duration;
import java.time.Instant;

import lb2.java.ComputableArray;

class Main {
    public static void main (String[] args) {
        // Java version using System.currentTimeMillis()
        var ca = new ComputableArray(300000000, 1);

        System.out.println("\n-----\n");

        // Measure synchronous execution using System.currentTimeMillis()
        long startSyncTime = System.currentTimeMillis();
        var minSync = ca.minSync();
        long endSyncTime = System.currentTimeMillis();
        long syncElapsedTime = endSyncTime - startSyncTime;

        System.out.println("Sync result:" + minSync + "\n" + syncElapsedTime + "ms");

        System.out.println("\n-----\n");

        // Measure asynchronous execution using System.currentTimeMillis()
        long startAsyncTime = System.currentTimeMillis();
        var minAsync = ca.minAsync();
        long endAsyncTime = System.currentTimeMillis();
        long asyncElapsedTime = endAsyncTime - startAsyncTime;

        System.out.println("Async result:" + minAsync + "\n" + asyncElapsedTime + "ms");
        System.out.println("\n-----\n");
        
    }
}